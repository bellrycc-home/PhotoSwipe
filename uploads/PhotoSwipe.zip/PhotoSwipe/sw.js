const CACHE = 'photoswiper-v5';
const ASSETS = [
  './photoswiper_v2.html',
  './manifest.json',
  './thumbnail-worker.js',
  './duplicate-worker.js',
  './tailwindcss.js',
  './ia-alert.css',
  './ia-alert.js'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).catch(()=>{}));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(resp => {
    const copy = resp.clone();
    caches.open(CACHE).then(c => c.put(e.request, copy)).catch(()=>{});
    return resp;
  }).catch(()=>caches.match('./photoswiper_v2.html'))));
});
