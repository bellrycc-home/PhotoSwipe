const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests',
  timeout: 60000,
  use: {
    baseURL: 'http://localhost:8765',
    headless: true,
  },
  webServer: {
    command: 'python3 -m http.server 8765',
    url: 'http://localhost:8765/photoswiper_v2.html',
    reuseExistingServer: true,
    cwd: '.',
    timeout: 30000,
  },
});
