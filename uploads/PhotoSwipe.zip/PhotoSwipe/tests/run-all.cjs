const { chromium } = require('playwright');
const path = require('path');

const FIXTURES = path.join(__dirname, 'fixtures');
const BASE = 'http://localhost:8765';

let serverProc = null;
function startServer() {
  const { spawn } = require('child_process');
  serverProc = spawn('python3', ['-m', 'http.server', '8765'], {
    cwd: path.join(__dirname, '..'),
    stdio: 'ignore',
  });
  return new Promise((resolve) => setTimeout(resolve, 1500));
}
function stopServer() { if (serverProc) serverProc.kill(); }

async function run() {
  await startServer();
  let failures = 0;

  async function scenario(name, fn) {
    const browser = await chromium.launch({ headless: true, executablePath: '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    const context = await browser.newContext({ acceptDownloads: true });
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    try {
      await fn(page, errors);
      console.log(`PASS: ${name}`);
    } catch (e) {
      failures++;
      console.log(`FAIL: ${name} -> ${e.message}`);
    } finally {
      try { await page.close(); } catch (_) {}
      try { await context.close(); } catch (_) {}
      try { await browser.close(); } catch (_) {}
    }
  }

  await scenario('carga sin errores críticos', async (page, errors) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.waitForTimeout(1000);
    if (errors.length) throw new Error(errors.join('; '));
  });

  await scenario('IA_Alert escritorio: 30s inicial, icono y popup', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.waitForTimeout(800);
    const cfg = await page.evaluate(() => (window.__iaAlert ? window.__iaAlert.config : null));
    if (!cfg) throw new Error('IAAlert no montado');
    if (cfg.collapseAfter !== 30000) throw new Error('collapseAfter=' + cfg.collapseAfter);
    if (cfg.touch !== false) throw new Error('detectado como touch en escritorio');
    if (!(await page.evaluate(() => document.querySelector('.ia-alert-widget').classList.contains('expanded')))) {
      throw new Error('widget no expandido al cargar');
    }
    if (await page.isVisible('.ia-alert-mobile-banner')) throw new Error('cartel móvil visible en escritorio');
    // Colapsar manualmente y verificar colider + popup
    await page.evaluate(() => window.__iaAlert.collapse());
    await page.waitForTimeout(400);
    const box = await page.locator('.ia-alert-widget').boundingBox();
    if (Math.abs(box.width - 44) > 6) throw new Error('no colapsa a 44px: ' + box.width);
    const collider = await page.locator('.ia-alert-collider').boundingBox();
    if (!collider || collider.width < 150) throw new Error('colider no grande');
    await page.click('.ia-alert-widget');
    await page.waitForTimeout(400);
    if (!(await page.isVisible('.ia-alert-popup-backdrop'))) throw new Error('popup no abre');
    await page.click('.ia-alert-popup-close');
  });

  await scenario('carga carpeta y muestra swipe', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    if (!(await page.isVisible('#swipeView'))) throw new Error('swipeView no visible');
  });

  await scenario('atajos clasifican y deshacen', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(1000);
    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(1000);
    await page.keyboard.press('ArrowDown');
    await page.waitForTimeout(1000);
    const status = await page.evaluate(() => photos[1].status);
    if (status !== 'pending') throw new Error(`status=${status}`);
  });

  await scenario('lightbox decide', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.evaluate(() => openLightbox(0));
    await page.waitForTimeout(500);
    if (!(await page.isVisible('#lightboxModal'))) throw new Error('lightbox no visible');
    await page.click("button:has-text('✓ Conservar')");
    await page.waitForTimeout(500);
    const status = await page.evaluate(() => photos[0].status);
    if (status !== 'keep') throw new Error(`status=${status}`);
  });

  await scenario('revisión muestra miniaturas', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(1000);
    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(1000);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Revisar y Limpiar")').catch(() => {});
    await page.waitForTimeout(3000);
    if (!(await page.isVisible('#summaryView'))) throw new Error('summary no visible');
    const count = await page.locator('#reviewGrid img').count();
    if (count < 1) throw new Error('sin miniaturas');
  });

  // duplicate scenario skipped for debugging

  // security scenario skipped

  await scenario('detección de duplicados no rompe', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(500);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(500);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(500);
    await page.click('button:has-text("Revisar y Limpiar")').catch(() => {});
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Detectar duplicados")');
    await page.waitForTimeout(5000);
    if (!(await page.isVisible('#summaryView'))) throw new Error('summary no visible');
  });

  await scenario('seguridad: nombre malicioso no ejecuta XSS', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.waitForTimeout(500);
    await page.evaluate(() => {
      window.__xss = false;
      const p = {
        id: crypto.randomUUID(),
        name: '<img src=x onerror="window.__xss=true">',
        file: new File(['x'], 'x.png', { type: 'image/png' }),
        url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7Zx2sAAAAASUVORK5CYII=',
        size: 1,
        width: 1,
        height: 1,
        status: 'delete',
        isFromDeletedFolder: false,
        isDuplicate: false,
      };
      photos.push(p);
      currentReviewTab = 'delete';
      renderReviewGrid();
    });
    await page.waitForTimeout(1000);
    const xss = await page.evaluate(() => window.__xss);
    if (xss === true) throw new Error('XSS ejecutado');
    const html = await page.locator('#reviewGrid').innerHTML();
    if (html.includes('<img src=x onerror=')) throw new Error('nombre no escapado');
  });

  await scenario('reset vuelve a inicio', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.evaluate(async () => {
      localStorage.clear();
      await new Promise((resolve) => {
        const req = indexedDB.deleteDatabase('photoswiper_db');
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    });
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.click('button:has-text("Revisar y Limpiar")').catch(() => {});
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Cargar otra carpeta")');
    await page.waitForTimeout(500);
    if (!(await page.isVisible('#setupView'))) throw new Error('setup no visible');
  });

  await scenario('IA_Alert modo móvil: cartel, tap reabre y fab', async (page) => {
    await page.goto(`${BASE}/photoswiper_v2.html`);
    await page.waitForTimeout(600);
    // Forzar modo táctil con tiempos cortos para no esperar 30s
    await page.evaluate(() => {
      if (window.__iaAlert) window.__iaAlert.destroy();
      window.__iaAlert = IAAlert.mount({
        container: document.querySelector('header'),
        before: document.getElementById('headerControls'),
        message: 'Esta web ha sido generada con IA y no ha sido revisada por un humano.',
        collapseAfter: 1200,
        hoverCloseDelay: 400,
        touch: true,
      });
    });
    await page.waitForTimeout(300);
    if (!(await page.isVisible('.ia-alert-mobile-banner'))) throw new Error('cartel no visible');
    if (await page.isVisible('.ia-alert-fab')) throw new Error('fab visible con cartel abierto');
    await page.waitForTimeout(2200); // supera los 1200ms de auto-cierre
    if (await page.isVisible('.ia-alert-mobile-banner')) throw new Error('cartel no se cerró solo');
    if (!(await page.isVisible('.ia-alert-fab'))) throw new Error('fab no apareció');
    await page.click('.ia-alert-fab');
    await page.waitForTimeout(400);
    if (!(await page.isVisible('.ia-alert-mobile-banner'))) throw new Error('tap en fab no reabre');
    await page.click('.ia-alert-mobile-close');
    await page.waitForTimeout(500);
    if (await page.isVisible('.ia-alert-mobile-banner')) throw new Error('X no cerró');
    if (!(await page.isVisible('.ia-alert-fab'))) throw new Error('advertencia desapareció (fab ausente)');
  });

  stopServer();

  if (failures > 0) {
    console.log(`\n${failures} escenario(s) fallaron.`);
    process.exitCode = 1;
  } else {
    console.log('\nTodos los escenarios pasaron.');
  }
}

run().catch((e) => {
  console.error('ERROR FATAL:', e);
  stopServer();
  process.exitCode = 1;
});
