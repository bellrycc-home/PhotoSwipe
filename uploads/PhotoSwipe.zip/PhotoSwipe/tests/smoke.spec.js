const { test, expect } = require('@playwright/test');
const path = require('path');

const FIXTURES = path.join(__dirname, 'fixtures');

test.describe('PhotoSwiper v2', () => {
  test('carga la página sin errores de consola críticos', async ({ page }) => {
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto('/photoswiper_v2.html');
    await page.waitForTimeout(1000);
    expect(errors).toEqual([]);
  });

  test('carga una carpeta y muestra la vista de swipe', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await expect(page.locator('#swipeView')).toBeVisible();
    await expect(page.locator('#currentCardImg')).toHaveAttribute('src', /blob:/);
  });

  test('atajos de teclado clasifican y deshacen', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);

    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(400);
    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(400);

    await page.keyboard.press('ArrowDown');
    await page.waitForTimeout(400);

    const status = await page.evaluate(() => photos[1].status);
    expect(status).toBe('pending');
  });

  test('lightbox se abre y permite decidir', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);

    await page.evaluate(() => openLightbox(0));
    await page.waitForTimeout(300);
    await expect(page.locator('#lightboxModal')).toBeVisible();

    await page.click("button:has-text('✓ Conservar')");
    await page.waitForTimeout(300);
    const status = await page.evaluate(() => photos[0].status);
    expect(status).toBe('keep');
  });

  test('vista de revisión muestra miniaturas y permite cambiar estado', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);

    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(300);
    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(300);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(300);

    await page.click('button:has-text("Revisar y Limpiar")');
    await page.waitForTimeout(2000);
    await expect(page.locator('#summaryView')).toBeVisible();
    await expect(page.locator('#reviewGrid img')).toHaveCount(1, { timeout: 10000 });

    await page.locator('#reviewGrid > div').first().click();
    await page.waitForTimeout(300);
  });

  test('detección de duplicados marca badge DUP cuando aplica', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);

    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(200);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(200);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(200);

    await page.click('button:has-text("Revisar y Limpiar")');
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Detectar duplicados")');
    await page.waitForTimeout(4000);
    // No assertion fuerte: solo verificar que no rompe
    await expect(page.locator('#summaryView')).toBeVisible();
  });

  test('exporta CSV y JSON sin errores', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);

    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(300);

    await page.click('button:has-text("Revisar y Limpiar")');
    await page.waitForTimeout(1000);

    const csvDownload = page.waitForEvent('download', { timeout: 10000 }).catch(() => null);
    await page.click('button:has-text("Exportar reporte CSV")');
    // may or may not download; ensure no crash
    await page.waitForTimeout(500);

    const jsonDownload = page.waitForEvent('download', { timeout: 10000 }).catch(() => null);
    await page.click('button:has-text("Exportar reporte JSON")');
    await page.waitForTimeout(500);
  });

  test('reset de la app vuelve a la vista inicial', async ({ page }) => {
    await page.goto('/photoswiper_v2.html');
    await page.setInputFiles('#fileInput', FIXTURES);
    await page.waitForTimeout(2000);
    await page.click('button:has-text("Revisar y Limpiar")');
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Cargar otra carpeta")');
    await page.waitForTimeout(500);
    await expect(page.locator('#setupView')).toBeVisible();
  });
});
