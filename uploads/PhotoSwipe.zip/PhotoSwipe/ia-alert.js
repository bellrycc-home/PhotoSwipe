(function (global) {
  'use strict';

  const DEFAULT_MESSAGE = 'Esta web ha sido generada con IA y no ha sido revisada por un humano.';

  function createIcon(size) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('width', size || 22);
    svg.setAttribute('height', size || 22);
    svg.classList.add('ia-alert-icon');
    svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M12 3 L21.5 19.5 H2.5 Z"></path><line x1="12" y1="9" x2="12" y2="13.5" stroke-linecap="round"></line><circle cx="12" cy="16.5" r="0.9" fill="currentColor" stroke="none"></circle>';
    return svg;
  }

  function isTouchDevice() {
    try {
      if (window.matchMedia('(hover: none)').matches) return true;
    } catch (e) { /* ignore */ }
    return 'ontouchstart' in window;
  }

  function mount(options) {
    options = options || {};
    const container = options.container || document.body;
    const before = options.before || null;
    const message = options.message || DEFAULT_MESSAGE;
    const initialOpenMs = typeof options.collapseAfter === 'number' ? options.collapseAfter : 30000;
    const hoverCloseMs = typeof options.hoverCloseDelay === 'number' ? options.hoverCloseDelay : 5000;
    const touch = typeof options.touch === 'boolean' ? options.touch : isTouchDevice();

    if (!container) return null;

    // Popup compartido
    const backdrop = document.createElement('div');
    backdrop.className = 'ia-alert-popup-backdrop';
    const popup = document.createElement('div');
    popup.className = 'ia-alert-popup';
    const popupHeader = document.createElement('div');
    popupHeader.className = 'ia-alert-popup-header';
    popupHeader.appendChild(createIcon(20));
    const popupTitle = document.createElement('div');
    popupTitle.className = 'ia-alert-popup-title';
    popupTitle.textContent = 'Advertencia';
    popupHeader.appendChild(popupTitle);
    const popupBody = document.createElement('div');
    popupBody.className = 'ia-alert-popup-body';
    popupBody.textContent = message;
    const popupCloseBtn = document.createElement('button');
    popupCloseBtn.className = 'ia-alert-popup-close';
    popupCloseBtn.textContent = 'Entendido';
    popupCloseBtn.addEventListener('click', () => { backdrop.style.display = 'none'; });
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) backdrop.style.display = 'none';
    });
    popup.appendChild(popupHeader);
    popup.appendChild(popupBody);
    popup.appendChild(popupCloseBtn);
    backdrop.appendChild(popup);
    document.body.appendChild(backdrop);

    let collapseTimer = null;
    let hoverTimer = null;
    const extraCleanup = [];
    let expandFn;
    let collapseFn;

    function scheduleCollapse(delay) {
      clearTimeout(collapseTimer);
      collapseTimer = setTimeout(() => { collapseFn(); }, delay);
    }

    function openPopup() { backdrop.style.display = 'flex'; }

    if (touch) {
      // ===== Modo movil / tactil: cartel arriba + icono pequeño =====
      const banner = document.createElement('div');
      banner.className = 'ia-alert-mobile-banner';
      banner.setAttribute('role', 'status');
      banner.appendChild(createIcon(18));
      const bannerText = document.createElement('span');
      bannerText.className = 'ia-alert-mobile-text';
      bannerText.textContent = message;
      banner.appendChild(bannerText);
      const bannerClose = document.createElement('button');
      bannerClose.className = 'ia-alert-mobile-close';
      bannerClose.setAttribute('aria-label', 'Cerrar aviso');
      bannerClose.innerHTML = '&times;';
      banner.appendChild(bannerClose);

      const fab = document.createElement('button');
      fab.className = 'ia-alert-fab';
      fab.setAttribute('aria-label', 'Mostrar advertencia de IA');
      fab.appendChild(createIcon(20));

      document.body.appendChild(banner);
      document.body.appendChild(fab);
      extraCleanup.push(banner, fab);

      expandFn = function () {
        fab.classList.remove('ia-alert-visible');
        banner.classList.remove('ia-alert-hiding');
        banner.style.display = 'flex';
        scheduleCollapse(initialOpenMs);
      };

      collapseFn = function () {
        clearTimeout(collapseTimer);
        banner.classList.add('ia-alert-hiding');
        setTimeout(() => {
          banner.style.display = 'none';
          banner.classList.remove('ia-alert-hiding');
          fab.classList.add('ia-alert-visible');
        }, 280);
      };

      bannerClose.addEventListener('click', () => { collapseFn(); });
      fab.addEventListener('click', () => { expandFn(); });

      // Inicio: cartel visible
      expandFn();
    } else {
      // ===== Escritorio: widget integrado en el contenedor =====
      const computed = window.getComputedStyle(container).position;
      if (computed === 'static') container.style.position = 'relative';

      const host = document.createElement('div');
      host.className = 'ia-alert-host';

      const widget = document.createElement('div');
      widget.className = 'ia-alert-widget expanded';
      widget.setAttribute('role', 'button');
      widget.setAttribute('aria-label', 'Advertencia de IA');
      widget.appendChild(createIcon());
      const text = document.createElement('span');
      text.className = 'ia-alert-text';
      text.textContent = message;
      widget.appendChild(text);

      const collider = document.createElement('div');
      collider.className = 'ia-alert-collider';

      expandFn = function () {
        widget.classList.add('expanded');
      };
      collapseFn = function () {
        widget.classList.remove('expanded');
      };

      // Hover en el colider (o en el propio icono) mantiene abierto; al salir, colapsa en hoverCloseMs
      function onHoverEnter() {
        clearTimeout(collapseTimer);
        clearTimeout(hoverTimer);
        expandFn();
      }
      function onHoverLeave() {
        clearTimeout(hoverTimer);
        hoverTimer = setTimeout(() => { collapseFn(); }, hoverCloseMs);
      }
      collider.addEventListener('mouseenter', onHoverEnter);
      collider.addEventListener('mouseleave', onHoverLeave);
      widget.addEventListener('mouseenter', onHoverEnter);
      widget.addEventListener('mouseleave', onHoverLeave);

      // Click abre popup
      widget.addEventListener('click', openPopup);

      host.appendChild(widget);
      container.appendChild(collider);
      extraCleanup.push(host, collider);

      if (before && before.parentNode === container) {
        container.insertBefore(host, before);
      } else {
        container.appendChild(host);
      }

      // Inicio: expandido y se colapsa tras initialOpenMs (30s por defecto)
      expandFn();
      scheduleCollapse(initialOpenMs);
    }

    return {
      expand: expandFn,
      collapse: collapseFn,
      openPopup: openPopup,
      config: { collapseAfter: initialOpenMs, hoverCloseDelay: hoverCloseMs, touch: touch },
      destroy: function () {
        clearTimeout(collapseTimer);
        clearTimeout(hoverTimer);
        extraCleanup.forEach((el) => el.remove());
        backdrop.remove();
      },
    };
  }

  global.IAAlert = { mount: mount, isTouchDevice: isTouchDevice };
})(window);
