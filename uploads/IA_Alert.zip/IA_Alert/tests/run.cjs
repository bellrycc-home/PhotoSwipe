// Uso: npm i && npx playwright install chromium && npm test
// Opcional: CHROMIUM_PATH=/ruta/a/chromium npm test
require('./ia-alert.test.cjs');
