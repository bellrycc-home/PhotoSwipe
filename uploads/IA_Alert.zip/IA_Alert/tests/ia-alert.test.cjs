const http = require('http');
const fs = require('fs');
const path = require('path');
const { chromium, devices } = require('playwright');

const ROOT = path.join(__dirname, '..');
const FAST = { collapseAfter: 1500, hoverCloseDelay: 800 };
const LIGHT = 'body{background:#fff;color:#111}';
const DARK = 'body{background:#020617;color:#e2e8f0}';
let passed = 0;

function ok(cond, msg) { if (!cond) throw new Error(msg); passed++; console.log('  ✓', msg); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function startServer() {
  const srv = http.createServer((req, res) => {
    const f = path.join(ROOT, req.url.split('?')[0].replace(/^\/+/, '') || 'index.html');
    if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end(); }
    const type = f.endsWith('.js') ? 'text/javascript' : 'text/html';
    res.writeHead(200, { 'Content-Type': type }); res.end(fs.readFileSync(f));
  });
  return new Promise((r) => srv.listen(0, () => r(srv)));
}

// Página de prueba: cabecera con logo/botones + contenido largo
function pageHtml(base, { cfg = {}, css = DARK, mountInHead = false, auto = '', lang = 'es' } = {}) {
  const mount = `window.ia = IAAlert.mount(${JSON.stringify({ ...FAST, ...cfg })});`;
  return `<!DOCTYPE html><html lang="${lang}"><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;font-family:system-ui}${css}
header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.5rem;background:inherit}
.logo{font-weight:700}#ctl{display:flex;gap:.5rem}</style>
<script src="${base}/ia-alert.js" ${auto}></script>
${mountInHead ? `<script>${mount}</script>` : ''}
</head><body><header><div class="logo">Mi App</div><div id="ctl"><button>Botón</button></div></header>
<div style="height:3000px">contenido largo</div>
${!mountInHead && !auto ? `<script>${mount}</script>` : ''}</body></html>`;
}

const rect = (page, sel) => page.evaluate((s) => { const r = document.querySelector(s).getBoundingClientRect(); return { l: r.left, r: r.right, t: r.top, b: r.bottom, w: r.width, h: r.height }; }, sel);
const isOpen = (page) => page.evaluate(() => document.querySelector('.ia-alert-widget').classList.contains('ia-alert-expanded'));
const visible = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return !!e && !e.hidden && getComputedStyle(e).display !== 'none'; }, sel);

function lum([r, g, b]) { const f = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); }
function contrast(a, b) { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); }
async function contrastOf(page, pageBg) {
  const c = await page.evaluate(() => {
    const w = document.querySelector('.ia-alert-widget'), tx = document.querySelector('.ia-alert-text');
    const p = (s) => s.match(/[\d.]+/g).map(Number);
    return { fg: p(getComputedStyle(tx).color), bg: p(getComputedStyle(w).backgroundColor) };
  });
  const a = c.bg[3] === undefined ? 1 : c.bg[3];
  const bg = [0, 1, 2].map((i) => c.bg[i] * a + pageBg[i] * (1 - a));
  return contrast(c.fg.slice(0, 3), bg);
}

(async () => {
  const srv = await startServer();
  const base = `http://localhost:${srv.address().port}`;
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'], executablePath: process.env.CHROMIUM_PATH || undefined });
  const errors = [];
  const track = (p) => { p.on('pageerror', (e) => errors.push(e.message)); p.on('console', (m) => m.type() === 'error' && errors.push(m.text())); };

  // ===== ESCRITORIO =====
  console.log('Escritorio');
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } }); track(page);
    await page.setContent(pageHtml(base, { cfg: { before: '#ctl' } }));
    await page.waitForSelector('.ia-alert-widget');
    ok(await isOpen(page), 'arranca expandido');
    ok(!(await visible(page, '.ia-alert-banner')), 'sin cartel móvil en escritorio');

    const fit = await page.evaluate(() => { const w = document.querySelector('.ia-alert-widget').getBoundingClientRect(), t = document.querySelector('.ia-alert-text').getBoundingClientRect(); return t.right <= w.right + 1 && t.bottom <= w.bottom + 1; });
    ok(fit, 'el mensaje completo cabe dentro del cuadrado (sin cortarse)');

    for (const w of [1280, 800]) {
      await page.setViewportSize({ width: w, height: 800 }); await sleep(200);
      const [wd, lg, ct] = [await rect(page, '.ia-alert-widget'), await rect(page, '.logo'), await rect(page, '#ctl')];
      ok(wd.l >= lg.r && wd.r <= ct.l, `no se solapa con logo ni botones a ${w}px`);
    }
    await page.setViewportSize({ width: 1280, height: 800 });

    ok(await isOpen(page), 'sigue abierto antes de collapseAfter');
    await sleep(1800);
    ok(!(await isOpen(page)), 'colapsa tras collapseAfter');
    ok(Math.abs((await rect(page, '.ia-alert-widget')).w - 44) < 4, 'colapsado = cuadrado de 44px');

    const r = await rect(page, '.ia-alert-widget');
    await page.mouse.move(r.l - 10, r.t + r.h / 2); await sleep(500); // dentro del colider, fuera del cuadrado
    ok(await isOpen(page), 'hover en el colider invisible lo abre');
    await page.mouse.move(5, 700); await sleep(400);
    ok(await isOpen(page), 'al salir sigue abierto antes de hoverCloseDelay');
    await sleep(700);
    ok(!(await isOpen(page)), 'se cierra tras hoverCloseDelay al salir');

    await page.click('.ia-alert-widget'); await sleep(200);
    ok(await visible(page, '.ia-alert-backdrop'), 'clic abre el popup');
    ok(await page.evaluate(() => !!document.querySelector('.ia-alert-popup[role=dialog][aria-modal=true]')), 'popup con role=dialog y aria-modal');
    await page.keyboard.press('Escape');
    ok(!(await visible(page, '.ia-alert-backdrop')), 'Escape cierra el popup');
    await page.click('.ia-alert-widget'); await page.click('.ia-alert-popup-close');
    ok(!(await visible(page, '.ia-alert-backdrop')), '«Entendido» cierra el popup');

    await page.evaluate(() => document.querySelector('.ia-alert-widget').focus());
    await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab'); // foco por teclado
    await page.keyboard.press('Enter'); await sleep(150);
    ok(await visible(page, '.ia-alert-backdrop'), 'Enter (teclado) abre el popup');
    await page.keyboard.press('Escape');
    ok(await page.evaluate(() => document.activeElement.classList.contains('ia-alert-widget')), 'Escape devuelve el foco al icono');

    // destroy / doble mount
    await page.evaluate(() => { IAAlert.mount({ before: '#ctl' }); });
    ok(await page.evaluate(() => document.querySelectorAll('.ia-alert-widget').length) === 1, 'montar dos veces deja una sola alerta');
    await page.evaluate(() => window.ia.destroy());
    ok(await page.evaluate(() => document.querySelectorAll('[class*=ia-alert-]:not(style)').length) >= 0, 'destroy ejecutado sin errores');
    await page.close();
  }

  // Modo flotante sin container
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } }); track(page);
    await page.setContent(pageHtml(base));
    await page.waitForSelector('.ia-alert-widget');
    let r = await rect(page, '.ia-alert-widget');
    ok(r.l < 40 && r.b > 740 && r.b <= 800, 'sin container: flotante abajo-izquierda, visible al cargar');
    await page.evaluate(() => scrollTo(0, 2500)); await sleep(100);
    r = await rect(page, '.ia-alert-widget');
    ok(r.b > 740 && r.b <= 800, 'sigue visible tras hacer scroll');
    await page.close();
  }

  // Tema
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } }); track(page);
    await page.setContent(pageHtml(base, { css: LIGHT, cfg: { before: '#ctl' } }));
    await page.waitForSelector('.ia-alert-widget');
    ok(await page.evaluate(() => window.ia.config.theme) === 'light', 'fondo claro → tema light');
    ok((await contrastOf(page, [255, 255, 255])) >= 4.5, 'contraste ≥ 4.5 sobre fondo claro');
    await page.evaluate(() => { document.body.style.background = '#020617'; window.ia.refreshTheme(); });
    ok(await page.evaluate(() => window.ia.config.theme) === 'dark', 'refreshTheme() detecta fondo oscuro');
    ok((await contrastOf(page, [2, 6, 23])) >= 4.5, 'contraste ≥ 4.5 sobre fondo oscuro');
    await page.close();
  }

  // Integración: <head>, auto-init y mensaje largo
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } }); track(page);
    await page.setContent(pageHtml(base, { mountInHead: true }));
    await page.waitForSelector('.ia-alert-widget', { timeout: 3000 });
    ok(true, 'mount() desde <head> funciona (espera al DOM)');
    await page.setContent(pageHtml(base, { auto: 'data-ia-alert data-message="Texto de prueba auto" data-position="bottom-right" data-collapse-after="1500"' }));
    await page.waitForSelector('.ia-alert-widget');
    ok((await page.textContent('.ia-alert-text')) === 'Texto de prueba auto', 'auto-init por data-attributes (mensaje)');
    const r = await rect(page, '.ia-alert-widget');
    ok(r.r > 1200, 'data-position=bottom-right aplicado');
    await page.setContent(pageHtml(base, { lang: 'en' }));
    await page.waitForSelector('.ia-alert-widget');
    ok((await page.textContent('.ia-alert-text')).startsWith('This website'), 'idioma por <html lang="en">');
    const long = 'Mensaje muy largo de prueba. '.repeat(8);
    await page.setContent(pageHtml(base, { cfg: { message: long } }));
    await page.waitForSelector('.ia-alert-widget');
    const g = await page.evaluate(() => { const w = document.querySelector('.ia-alert-widget').getBoundingClientRect(), t = document.querySelector('.ia-alert-text').getBoundingClientRect(); return { h: w.height, w: w.width, inside: t.right <= w.right + 1 && t.bottom <= w.bottom + 1, vw: innerWidth }; });
    ok(g.h > 44 && g.w <= 460 && g.inside, 'mensaje largo: crece en alto y no se corta');
    await page.close();
  }

  // Touch-laptop: ontouchstart existe pero el puntero es ratón → debe ser escritorio
  {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    await ctx.addInitScript(() => { window.ontouchstart = null; });
    const page = await ctx.newPage(); track(page);
    await page.setContent(pageHtml(base));
    await page.waitForSelector('.ia-alert-widget');
    ok(await page.evaluate(() => window.ia.config.mode) === 'desktop', 'portátil táctil con ratón → modo escritorio');
    // Cambio de modo al redimensionar
    await page.setViewportSize({ width: 500, height: 800 }); await sleep(300);
    ok(await page.evaluate(() => window.ia.config.mode) === 'mobile' && await visible(page, '.ia-alert-banner'), 'ventana <640px → cambia a cartel móvil');
    await page.setViewportSize({ width: 1280, height: 800 }); await sleep(300);
    ok(await page.evaluate(() => window.ia.config.mode) === 'desktop' && await visible(page, '.ia-alert-widget'), 'al ensanchar vuelve a escritorio');
    await ctx.close();
  }

  // ===== MÓVIL =====
  console.log('Móvil');
  {
    const ctx = await browser.newContext({ ...devices['iPhone 13'] });
    const page = await ctx.newPage(); track(page);
    await page.setContent(pageHtml(base));
    await page.waitForSelector('.ia-alert-banner');
    ok(await page.evaluate(() => window.ia.config.mode) === 'mobile', 'detectado como móvil');
    ok(await visible(page, '.ia-alert-banner') && !(await visible(page, '.ia-alert-fab')), 'cartel visible, icono oculto');
    ok(!(await visible(page, '.ia-alert-widget')), 'sin widget de escritorio');
    const b = await rect(page, '.ia-alert-banner');
    ok(b.l >= 0 && b.r <= 390, 'cartel dentro del ancho de pantalla');
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'sin scroll horizontal');
    const c = await rect(page, '.ia-alert-banner-close');
    ok(c.w >= 36 && c.h >= 36, 'botón × con área táctil ≥ 36px');

    await sleep(1800);
    ok(!(await visible(page, '.ia-alert-banner')) && await visible(page, '.ia-alert-fab'), 'auto-cierre y aparece el icono');
    await sleep(400); // fin de la animación de entrada
    const f = await rect(page, '.ia-alert-fab');
    ok(f.w >= 44 && f.l < 40 && f.b > 600, 'icono ≥44px, abajo-izquierda');
    await page.tap('.ia-alert-fab'); await sleep(400);
    ok(await visible(page, '.ia-alert-banner') && !(await visible(page, '.ia-alert-fab')), 'tap en el icono reabre el cartel');
    ok((await page.textContent('.ia-alert-banner')).includes('IA'), 'el cartel contiene la leyenda');
    await page.tap('.ia-alert-banner-close'); await sleep(450);
    ok(!(await visible(page, '.ia-alert-banner')) && await visible(page, '.ia-alert-fab'), '× cierra y deja el icono');

    // carrera collapse() → expand() inmediato
    await page.evaluate(() => { window.ia.collapse(); window.ia.expand(); }); await sleep(500);
    ok(await visible(page, '.ia-alert-banner') && !(await visible(page, '.ia-alert-fab')), 'collapse()+expand() inmediatos no dejan el cartel oculto');

    await page.evaluate(() => window.ia.openPopup()); await sleep(200);
    ok(await visible(page, '.ia-alert-backdrop'), 'openPopup() funciona en móvil');
    await page.tap('.ia-alert-popup-close');
    ok(!(await visible(page, '.ia-alert-backdrop')), 'popup se cierra con «Entendido»');
    await ctx.close();
  }

  ok(errors.length === 0, 'cero errores en consola/página' + (errors.length ? ': ' + errors.join('; ') : ''));
  await browser.close(); srv.close();
  console.log(`\nIA_ALERT_ALL_OK (${passed} comprobaciones)`);
})().catch((e) => { console.error('\nFALLO:', e.message); process.exit(1); });
