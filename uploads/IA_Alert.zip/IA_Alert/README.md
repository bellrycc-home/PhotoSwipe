# IA_Alert 2.0

Aviso para webs hechas con trabajo agéntico / IA **sin revisión humana**.
Un solo archivo (`ia-alert.js`), sin dependencias, inyecta su propio CSS.
Escritorio: icono ⚠ que se expande con el mensaje. Móvil: cartel arriba + icono pequeño.

## Integración (1 línea)

```html
<script src="ia-alert.js" data-ia-alert></script>
```

Con opciones (todas opcionales):

```html
<script src="ia-alert.js" data-ia-alert
        data-before="#headerControls"   data-position="bottom-left"
        data-message="Texto propio"     data-collapse-after="30000"></script>
```

Desde JS (SPA / React / Next: llama a `destroy()` al desmontar):

```js
const alert = IAAlert.mount({ before: '#headerControls' });
// alert.destroy();
```

Funciona aunque el script esté en `<head>` (espera al DOM). Solo existe una alerta por página.

## Opciones

| Opción (`data-…`) | Defecto | Descripción |
|---|---|---|
| `message` | texto en es/en según `<html lang>` | Leyenda |
| `details` | = message | Texto del popup |
| `lang` | `<html lang>` | `es` o `en` |
| `container` | — | Selector/elemento donde se inserta en línea (p. ej. `header`) |
| `before` | — | Selector/elemento delante del cual se inserta (basta con esto; deduce el container) |
| `position` | `bottom-left` | Sin container: `bottom-left`, `bottom-right`, `top-left`, `top-right` |
| `theme` | `auto` | `auto` (detecta el fondo real), `light`, `dark` |
| `collapseAfter` | `30000` | ms hasta colapsar solo |
| `hoverCloseDelay` | `5000` | ms en cerrar tras salir del colider |
| `mobileBreakpoint` | `640` | Por debajo de este ancho (px) se usa el modo móvil |
| `touch` | auto | `true`/`false` fuerza modo móvil/escritorio |

`mount()` devuelve `{ expand, collapse, openPopup, refreshTheme, config, destroy }`.
Llama a `refreshTheme()` si tu web cambia de tema claro/oscuro en caliente.

## Comportamiento

**Escritorio** (puntero fino y ancho ≥ 640px): arranca expandido, colapsa a los `collapseAfter` ms. Un
«colider» invisible de 18px alrededor mantiene el mensaje abierto con el ratón (ajustable con `--ia-alert-hit`);
al salir cierra a los `hoverCloseDelay` ms. Crece en ancho y, si el mensaje es largo, en alto (nunca se corta).
Clic / Enter abre el popup (`role="dialog"`, Escape cierra, devuelve el foco).

**Móvil / táctil**: cartel superior con ×, se cierra solo a `collapseAfter`; queda un icono (44px) que lo reabre.
Respeta las zonas seguras de iOS (notch). El modo se reevalúa al girar o redimensionar.

Colores personalizables sobrescribiendo variables CSS (`--ia-bg`, `--ia-fg`, `--ia-border`, `--ia-icon`…) en `.ia-alert-root`.

## Notas

- Webs con CSP estricta: añade `nonce` a la etiqueta `<script>`; se reutiliza para el `<style>` inyectado.
- El cartel móvil tapa la parte superior durante 30s (por diseño: es un aviso). Baja `collapseAfter` si molesta.
- El tema `auto` se detecta al montar; usa `refreshTheme()` si cambia después.

## Tests

```bash
npm i && npx playwright install chromium && npm test
```
Autocontenido (levanta su propio servidor, usa tiempos cortos). Opcional: `CHROMIUM_PATH=/ruta npm test`.
